package cs2321;

import static org.junit.Assert.*;

import org.junit.Test;

public class CircularArrayQueueTest {

	@Test
	public void testCircularArrayQueue() {
		
		CircularArrayQueue<Integer> test = new CircularArrayQueue<>(2);
		
		if ( test.size() != 0 )
		{
			fail("Implementation Error");
		}
		
	}

	@Test
	public void testSize() {
		
		CircularArrayQueue<Integer> test = new CircularArrayQueue<>(2);
		
		if ( test.size() != 0 )
		{
			fail("nothing in queue");
		}
		
		test.enqueue(1);
		
		if ( test.size() != 1 )
		{
			fail("1 element has been added");
		}
		
		test.dequeue();
		
		if ( test.size() != 0 )
		{
			fail("queue has been emptied");
		}
		
	}

	@Test
	public void testIsEmpty() {
		
		CircularArrayQueue<Integer> test = new CircularArrayQueue<>(2);
		
		if ( !test.isEmpty() )
		{
			fail("queue should currently be empty");
		}
		
		test.enqueue(1);
		
		if ( test.isEmpty() )
		{
			fail("queue should currently have an element");
		}
		
		test.dequeue();
		
		if ( !test.isEmpty() )
		{
			fail("queue should currently be empty");
		}
		
	}

	@Test
	public void testEnqueue() {
		
		CircularArrayQueue<Integer> test = new CircularArrayQueue<>(2);
		
		test.enqueue(1);
		
		if( test.size() != 1 )
		{
			fail("size after 1 enqueue failed");
		}
		
		test.enqueue(2);
		
		if ( test.size() != 2 )
		{
			fail("size and number of enqueues don't match");
		}
		
		try
		{
			test.enqueue(3);
			fail("no exception thrown");
		}
		catch(Exception e)
		{
		}
	}

	@Test
	public void testFirst() {
		
		CircularArrayQueue<Integer> test = new CircularArrayQueue<>(2);
		
		test.enqueue(1);
		
		if ( test.first() != 1 )
		{
			fail("first doesn't return correct value");
		}
		
	}

	@Test
	public void testDequeue() {
		
		CircularArrayQueue<Integer> test = new CircularArrayQueue<>(2);
		
		test.enqueue(1);
		test.enqueue(2);
		
		int ret = test.dequeue();
		
		if ( ret != 1 )
		{
			System.out.println(ret);
			fail("dequeue doesn't return correct value");
		}
		
		if ( test.first() != 2 )
		{
			System.out.println(test.first());
			fail("dequeue didn't link the list together properly");
		}
		
	}

}

package cs2321;

import static org.junit.Assert.*;

import org.junit.Test;

public class ArrayListTest {

	@Test
	public void testArrayList() {
		
		ArrayList<Integer> test = new ArrayList<>();
		
		if ( test.size() != 0 )
		{
			fail("Implementation incorrect");
		}
		
	}

	@Test
	public void testSize() {
		
		ArrayList<Integer> test = new ArrayList<>();
		
		if ( test.size() != 0 )
		{
			fail("ArrayList should be empty");
		}
		
		test.addLast(1);
		
		if ( test.size() != 1 )
		{
			fail("ArrayList should have an element");
		}
		
		test.removeFirst();
		
		if ( test.size() != 0 )
		{
			fail("ArrayList should be empty");
		}
		
	}

	@Test
	public void testIsEmpty() {
		
		ArrayList<Integer> test = new ArrayList<>();
		
		if ( !test.isEmpty() )
		{
			fail("queue should currently be empty");
		}
		
		test.addLast(1);
		
		if ( test.isEmpty() )
		{
			fail("queue should currently have an element");
		}
		
		test.removeFirst();
		
		if ( !test.isEmpty() )
		{
			fail("queue should currently be empty");
		}
		
	}

	@Test
	public void testGet() {
		
		ArrayList<Integer> test = new ArrayList<>();
		test.addLast(1);
		
		if ( test.get(0) != 1 )
		{
			fail("returned wrong value");
		}
		
		if ( test.isEmpty() )
		{
			fail("queue should not currently be empty");
		}
		
	}

	@Test
	public void testSet() {

		ArrayList<Integer> test = new ArrayList<>();
		test.addLast(1);
		test.set(0, 2);
		
		if ( test.get(0) != 2 )
		{
			fail("Value was not changed");
		}
		
	}

	@Test
	public void testAdd() {
		
		ArrayList<Integer> test = new ArrayList<>();
		test.add(0, 1);
		
		if ( test.isEmpty() )
		{
			fail("Did not add a value");
		}
		
		if ( test.get(0) != 1 )
		{
			fail("Did not add correct value");
		}
		
	}

	@Test
	public void testRemove() {
		
		ArrayList<Integer> test = new ArrayList<>();
		test.addLast(1);
		test.remove(0);
		
		if ( !test.isEmpty() )
		{
			fail("ArrayList should be empty");
		}
		
	}

	@Test
	public void testIterator() {

		ArrayList<Integer> test = new ArrayList<>();
		
		test.addLast(3);
		test.addLast(4);
		
		int ctr = 0;
		for ( Integer e : test )
		{
			test.set(ctr, e*2);
			ctr++;
		}
		
		if ( test.get(0) != 6 )
		{
			fail("Wasn't doubled");
		}
		
		if ( test.get(1) != 8 )
		{
			fail("Wasn't doubled");
		}
		
	}

	@Test
	public void testAddFirst() {
		
		ArrayList<Integer> test = new ArrayList<>();
		
		test.addFirst(1);
		
		if ( test.isEmpty() )
		{
			fail("Shouldn't be empty");
		}
		
	}

	@Test
	public void testAddLast() {

		ArrayList<Integer> test = new ArrayList<>();
		
		test.addLast(1);
		
		if ( test.isEmpty() )
		{
			fail("Shouldn't be empty");
		}
		
	}

	@Test
	public void testRemoveFirst() {

		ArrayList<Integer> test = new ArrayList<>();
		test.addLast(1);
		test.removeFirst();
		
		if ( !test.isEmpty() )
		{
			fail("ArrayList should be empty");
		}
		
	}

	@Test
	public void testRemoveLast() {

		ArrayList<Integer> test = new ArrayList<>();
		test.addLast(1);
		test.removeLast();
		
		if ( !test.isEmpty() )
		{
			fail("ArrayList should be empty");
		}
		
	}

}

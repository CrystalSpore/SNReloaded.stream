package cs2321;

import static org.junit.Assert.*;

import org.junit.Test;

public class DoublyLinkedListTest {

	@Test
	public void testDoublyLinkedList() {
		DoublyLinkedList<Integer> test = new DoublyLinkedList<>();
		if ( test.size() != 0 )
		{
			fail("Initial instance doesn't work");
		}
	}

	@Test
	public void testSize() {

		DoublyLinkedList<Integer> test = new DoublyLinkedList<>();
		
		if ( test.size() != 0 )
		{
			fail("ArrayList should be empty");
		}
		
		test.addLast(1);
		
		if ( test.size() != 1 )
		{
			fail("ArrayList should have an element");
		}
		
		test.removeFirst();
		
		if ( test.size() != 0 )
		{
			fail("ArrayList should be empty");
		}
		
	}

	@Test
	public void testIsEmpty() {

		DoublyLinkedList<Integer> test = new DoublyLinkedList<>();
		
		if ( !test.isEmpty() )
		{
			fail("queue should currently be empty");
		}
		
		test.addLast(1);
		
		if ( test.isEmpty() )
		{
			fail("queue should currently have an element");
		}
		
		test.removeFirst();
		
		if ( !test.isEmpty() )
		{
			fail("queue should currently be empty");
		}
		
	}

	@Test
	public void testFirst() {
		
		DoublyLinkedList<Integer> test = new DoublyLinkedList<>();

		test.addFirst(1);
		
		if ( test.first().getElement() != 1 )
		{
			fail("Didn't return correct element");
		}
		
	}

	@Test
	public void testLast() {
		
		DoublyLinkedList<Integer> test = new DoublyLinkedList<>();
		
		test.addFirst(1);
		
		if ( test.last().getElement() != 1 )
		{
			fail("Didn't return correct element");
		}
		
	}

	@Test
	public void testBefore() {
		
		DoublyLinkedList<Integer> test = new DoublyLinkedList<>();
		
		test.addLast(1);
		test.addLast(2);
		
		if ( test.before(test.last()).getElement() != 1 )
		{
			fail("Didn't return correct element");
		}
		
	}

	@Test
	public void testAfter() {

		DoublyLinkedList<Integer> test = new DoublyLinkedList<>();
		
		test.addLast(1);
		test.addLast(2);
		
		if ( test.after(test.first()).getElement() != 2 )
		{
			fail("Didn't return correct element");
		}
		
	}

	@Test
	public void testAddFirst() {
		
		DoublyLinkedList<Integer> test = new DoublyLinkedList<>();

		test.addFirst(1);
		test.addFirst(2);
		
		if ( test.first().getElement() != 2 )
		{
			fail("Didn't add before");
		}
		
	}

	@Test
	public void testAddLast() {
		
		DoublyLinkedList<Integer> test = new DoublyLinkedList<>();
		
		test.addLast(1);
		test.addLast(2);
		
		if ( test.first().getElement() != 1 )
		{
			fail("Didn't add after");
		}
		
	}

	@Test
	public void testAddBefore() {
		
		DoublyLinkedList<Integer> test = new DoublyLinkedList<>();
		
		test.addFirst(1);
		test.addBefore(test.first(), 2);
		
		if ( test.first().getElement() != 2 )
		{
			fail("Didn't add before");
		}
		
	}

	@Test
	public void testAddAfter() {

		DoublyLinkedList<Integer> test = new DoublyLinkedList<>();
		
		test.addFirst(1);
		test.addAfter(test.first(), 2);
		
		if ( test.last().getElement() != 2 )
		{
			fail("Didn't add after");
		}
		
	}

	@Test
	public void testSet() {
		
		DoublyLinkedList<Integer> test = new DoublyLinkedList<>();
		
		test.addFirst(1);
		test.set(test.first(), 2);
		
		if ( test.first().getElement() != 2 )
		{
			fail("Didn't set the element");
		}
		
	}

	@Test
	public void testRemove() {

		DoublyLinkedList<Integer> test = new DoublyLinkedList<>();
		
		test.addFirst(1);
		test.remove(test.first());
		
		if ( !test.isEmpty() )
		{
			fail("test should be empty");
		}
		
	}

	@Test
	public void testIterator() {

		DoublyLinkedList<Integer> test = new DoublyLinkedList<>();
		
		//fail("Not yet implemented"); //Unsure how to test
		
	}

	@Test
	public void testPositions() {
		
		DoublyLinkedList<Integer> test = new DoublyLinkedList<>();
		
		//fail("Not yet implemented"); //Unsure how to test
		
	}

	@Test
	public void testRemoveFirst() {
		
		DoublyLinkedList<Integer> test = new DoublyLinkedList<>();
		
		test.addFirst(1);
		test.removeFirst();
		
		if ( !test.isEmpty() )
		{
			fail("test should be empty");
		}
		
	}

	@Test
	public void testRemoveLast() {
		
		DoublyLinkedList<Integer> test = new DoublyLinkedList<>();
		
		test.addFirst(1);
		test.removeLast();
		
		if ( !test.isEmpty() )
		{
			fail("test should be empty");
		}
	}

}


class MyAccount 
{
   public:
      MyAccount(int Initial_Amount);
      int  Deposit(int);
      int  Withdraw(int);
      void Display(void);

   private:
      int  Balance;
};



#include <iostream>

using namespace std;

int main(void)
{
   cout << "Hello, world." << endl;
   return 0;
}

